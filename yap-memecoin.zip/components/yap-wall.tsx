"use client"

import { PostCard } from "@/components/post-card"
import { Card } from "@/components/ui/card"

interface Post {
  id: string
  walletAddress: string
  message: string
  timestamp: number
  upvotes: number
  upvotedBy: Set<string>
  postCount: number
}

interface YapWallProps {
  posts: Post[]
  currentWallet: string
  onUpvote: (postId: string) => void
}

export function YapWall({ posts, currentWallet, onUpvote }: YapWallProps) {
  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-4">
        <h2 className="text-2xl font-bold text-foreground">YAP WALL</h2>
        <div className="flex-1 h-px bg-border"></div>
        <div className="text-sm text-muted-foreground">{posts.length} active transmissions</div>
      </div>

      <div className="space-y-4 max-h-[800px] overflow-y-auto scrollbar-thin scrollbar-track-muted scrollbar-thumb-accent">
        {posts.length === 0 ? (
          <Card className="p-8 bg-card border-border text-center">
            <div className="text-muted-foreground">No active transmissions. Be the first to YAP!</div>
          </Card>
        ) : (
          posts.map((post) => <PostCard key={post.id} post={post} currentWallet={currentWallet} onUpvote={onUpvote} />)
        )}
      </div>
    </div>
  )
}
