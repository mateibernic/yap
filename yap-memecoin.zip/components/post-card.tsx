"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { ArrowUp, Flame } from "lucide-react"

interface Post {
  id: string
  walletAddress: string
  message: string
  timestamp: number
  upvotes: number
  upvotedBy: Set<string>
  postCount: number
}

interface PostCardProps {
  post: Post
  currentWallet: string
  onUpvote: (postId: string) => void
}

export function PostCard({ post, currentWallet, onUpvote }: PostCardProps) {
  const [glitchLevel, setGlitchLevel] = useState(0)
  const [showGlitch, setShowGlitch] = useState(false)
  const [currentTime, setCurrentTime] = useState(Date.now())

  // Update current time every second for live timestamps
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTime(Date.now())
    }, 1000)

    return () => clearInterval(interval)
  }, [])

  // Calculate glitch level based on post count and age
  useEffect(() => {
    const ageHours = (currentTime - post.timestamp) / (1000 * 60 * 60)
    const baseGlitch = Math.min(post.postCount * 0.2, 1)
    const ageGlitch = Math.min(ageHours * 0.1, 0.5)
    setGlitchLevel(baseGlitch + ageGlitch)
  }, [post.postCount, post.timestamp, currentTime])

  // Random glitch animation
  useEffect(() => {
    if (glitchLevel > 0.3) {
      const interval = setInterval(() => {
        if (Math.random() < glitchLevel) {
          setShowGlitch(true)
          setTimeout(() => setShowGlitch(false), 100)
        }
      }, 2000)
      return () => clearInterval(interval)
    }
  }, [glitchLevel])

  const formatTime = (timestamp: number) => {
    const diff = currentTime - timestamp
    const seconds = Math.floor(diff / 1000)
    const minutes = Math.floor(seconds / 60)

    if (seconds < 10) return "just now"
    if (seconds < 60) return `${seconds}s ago`
    if (minutes < 60) return `${minutes}m ago`

    const hours = Math.floor(minutes / 60)
    return `${hours}h ago`
  }

  const isUpvoted = post.upvotedBy.has(currentWallet)
  const glitchClass = showGlitch ? "animate-pulse opacity-70" : ""
  const decayOpacity = Math.max(0.4, 1 - glitchLevel * 0.6)

  return (
    <Card
      className={`p-4 bg-card border-border hover:border-accent/50 transition-all duration-300 ${glitchClass}`}
      style={{ opacity: decayOpacity }}
    >
      <div className="space-y-3">
        {/* Header */}
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center space-x-2">
            <span className="text-foreground font-mono font-bold">{post.walletAddress}</span>
            {post.postCount > 3 && <span className="text-muted-foreground text-xs">[FREQUENT POSTER]</span>}
          </div>
          <div className="text-muted-foreground">{formatTime(post.timestamp)}</div>
        </div>

        {/* Message */}
        <div className={`text-foreground leading-relaxed ${glitchLevel > 0.5 ? "filter blur-[0.5px]" : ""}`}>
          {post.message}
        </div>

        {/* Actions */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onUpvote(post.id)}
              className={`flex items-center space-x-1 ${
                isUpvoted ? "text-accent bg-accent/10" : "text-muted-foreground hover:text-accent"
              }`}
            >
              <ArrowUp className="w-4 h-4" />
              <span>{post.upvotes}</span>
            </Button>

            {glitchLevel > 0.6 && (
              <Button
                variant="ghost"
                size="sm"
                className="text-muted-foreground hover:text-muted-foreground/80 opacity-50 cursor-not-allowed"
                disabled
              >
                <Flame className="w-4 h-4 mr-1" />
                BURN TO CLEAN
              </Button>
            )}
          </div>

          {/* Decay indicator */}
          {glitchLevel > 0.3 && (
            <div className="text-xs text-muted-foreground">SIGNAL DEGRADING: {Math.round(glitchLevel * 100)}%</div>
          )}
        </div>
      </div>
    </Card>
  )
}
