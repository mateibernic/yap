"use client"

import { useState, useEffect } from "react"
import { ThemeToggle } from "@/components/theme-toggle"

export function Header() {
  const [glitch, setGlitch] = useState(false)

  useEffect(() => {
    const interval = setInterval(() => {
      setGlitch(true)
      setTimeout(() => setGlitch(false), 200)
    }, 3000)

    return () => clearInterval(interval)
  }, [])

  return (
    <header className="text-center space-y-4 relative">
      <div className="absolute top-0 right-0">
        <ThemeToggle />
      </div>

      <h1
        className={`text-8xl md:text-9xl font-bold text-foreground font-libre-baskerville ${glitch ? "animate-pulse" : ""}`}
      >
        $yap
      </h1>
      <div className="text-xl md:text-2xl text-muted-foreground tracking-wider">
        {">"} DECENTRALIZED NOISE PROTOCOL {"<"}
      </div>
      <div className="text-sm text-muted-foreground max-w-2xl mx-auto">
        One message per wallet per day. Make it count. Messages vanish in 24h.
      </div>
      <div className="flex justify-center space-x-4 text-xs text-muted-foreground items-center">
        <div className="flex items-center bg-green-500 text-white px-3 py-1 rounded-full animate-pulse">
          <span className="w-2 h-2 bg-white rounded-full mr-2 animate-ping"></span>
          <span className="font-bold">LIVE</span>
        </div>
        <span>|</span>
        <span>POSTS DECAY OVER TIME</span>
        <span>|</span>
        <span>UPVOTE TO AMPLIFY</span>
      </div>
    </header>
  )
}
