"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card } from "@/components/ui/card"

interface PostFormProps {
  onSubmit: (message: string) => void
  canPost: boolean
  currentWallet: string
  nextPostTime: number
}

export function PostForm({ onSubmit, canPost, currentWallet, nextPostTime }: PostFormProps) {
  const [message, setMessage] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!message.trim() || !canPost) return

    setIsSubmitting(true)
    await new Promise((resolve) => setTimeout(resolve, 500)) // Simulate network delay
    onSubmit(message.trim())
    setMessage("")
    setIsSubmitting(false)
  }

  const getTimeUntilNextPost = () => {
    if (canPost) return null
    const timeLeft = nextPostTime - Date.now()
    const hours = Math.floor(timeLeft / (1000 * 60 * 60))
    const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60))
    return `${hours}h ${minutes}m`
  }

  return (
    <Card className="p-6 bg-card border-border">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold text-foreground">TRANSMIT MESSAGE</h2>
          <div className="text-sm text-muted-foreground">
            Wallet: <span className="text-accent font-mono">{currentWallet}</span>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="relative">
            <Textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder={
                canPost ? "What's your YAP today? (280 chars max)" : "You've already posted today. Come back tomorrow."
              }
              maxLength={280}
              disabled={!canPost || isSubmitting}
              className="bg-background border-border text-foreground placeholder-muted-foreground resize-none h-24 font-mono focus:border-accent"
            />
            <div className="absolute bottom-2 right-2 text-xs text-muted-foreground">{message.length}/280</div>
          </div>

          <div className="flex items-center justify-between">
            <div className="text-sm">
              {!canPost && <span className="text-destructive">Next post available in: {getTimeUntilNextPost()}</span>}
            </div>

            <Button
              type="submit"
              disabled={!canPost || !message.trim() || isSubmitting}
              className="bg-accent text-accent-foreground font-bold hover:bg-accent/90 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isSubmitting ? "TRANSMITTING..." : "YAP IT"}
            </Button>
          </div>
        </form>
      </div>
    </Card>
  )
}
