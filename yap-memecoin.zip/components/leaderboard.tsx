"use client"

import { Card } from "@/components/ui/card"
import { Trophy, Crown, Award } from "lucide-react"

interface Post {
  id: string
  walletAddress: string
  message: string
  timestamp: number
  upvotes: number
  upvotedBy: Set<string>
  postCount: number
}

interface LeaderboardProps {
  posts: Post[]
}

export function Leaderboard({ posts }: LeaderboardProps) {
  // Get today's top posts
  const today = new Date()
  today.setHours(0, 0, 0, 0)

  const todaysPosts = posts.filter((post) => post.timestamp >= today.getTime())
  const topPosts = todaysPosts.sort((a, b) => b.upvotes - a.upvotes).slice(0, 5)

  const getIcon = (index: number) => {
    switch (index) {
      case 0:
        return <Crown className="w-4 h-4 text-accent" />
      case 1:
        return <Trophy className="w-4 h-4 text-muted-foreground" />
      case 2:
        return <Award className="w-4 h-4 text-muted-foreground" />
      default:
        return (
          <span className="w-4 h-4 flex items-center justify-center text-muted-foreground font-bold">{index + 1}</span>
        )
    }
  }

  return (
    <Card className="p-4 bg-card border-border sticky top-4">
      <div className="space-y-4">
        <div className="text-center">
          <h3 className="text-lg font-bold text-foreground mb-1">DAILY LEADERBOARD</h3>
          <div className="text-xs text-muted-foreground">Top YAPs by upvotes</div>
        </div>

        <div className="space-y-2">
          {topPosts.length === 0 ? (
            <div className="text-center text-muted-foreground text-sm py-4">No posts today yet</div>
          ) : (
            topPosts.map((post, index) => (
              <div
                key={post.id}
                className={`p-3 rounded border ${
                  index === 0 ? "bg-accent/5 border-accent/20" : "bg-muted/30 border-border"
                } hover:bg-muted/50 transition-colors`}
              >
                <div className="flex items-start space-x-2">
                  <div className="flex-shrink-0 mt-1">{getIcon(index)}</div>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs text-muted-foreground font-mono truncate">{post.walletAddress}</div>
                    <div className="text-sm text-foreground mt-1 line-clamp-2">{post.message}</div>
                    <div className="flex items-center justify-between mt-2 text-xs">
                      <span className="text-accent font-bold">{post.upvotes} upvotes</span>
                      <span className="text-muted-foreground">
                        {new Date(post.timestamp).toLocaleTimeString([], {
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Stats */}
        <div className="border-t border-border pt-3 space-y-2 text-xs">
          <div className="flex justify-between text-muted-foreground">
            <span>Total Posts Today:</span>
            <span className="text-foreground">{todaysPosts.length}</span>
          </div>
          <div className="flex justify-between text-muted-foreground">
            <span>Total Upvotes:</span>
            <span className="text-accent">{todaysPosts.reduce((sum, post) => sum + post.upvotes, 0)}</span>
          </div>
        </div>
      </div>
    </Card>
  )
}
