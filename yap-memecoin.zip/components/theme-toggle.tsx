"use client"

import { Moon, Sun } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useTheme } from "@/components/theme-provider"

export function ThemeToggle() {
  const { theme, toggleTheme } = useTheme()

  return (
    <Button
      variant="ghost"
      size="sm"
      onClick={toggleTheme}
      className="border border-border hover:border-accent transition-all duration-300"
    >
      <div className="flex items-center space-x-2">
        {theme === "light" ? (
          <>
            <Moon className="h-4 w-4 text-muted-foreground" />
            <span className="text-xs font-mono">DARK</span>
          </>
        ) : (
          <>
            <Sun className="h-4 w-4 text-muted-foreground" />
            <span className="text-xs font-mono">LIGHT</span>
          </>
        )}
      </div>
    </Button>
  )
}
