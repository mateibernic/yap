"use client"

import { useState, useEffect } from "react"
import { YapWall } from "@/components/yap-wall"
import { PostForm } from "@/components/post-form"
import { Leaderboard } from "@/components/leaderboard"
import { Header } from "@/components/header"
import { ThemeProvider } from "@/components/theme-provider"

// Generate random wallet address
const generateRandomWallet = () => {
  const chars = "0123456789abcdef"
  let result = "0x"
  for (let i = 0; i < 4; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length))
  }
  result += "..."
  for (let i = 0; i < 4; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length))
  }
  return result
}

// Mock data for initial posts - all within the last minute
const initialPosts = [
  {
    id: "1",
    walletAddress: "0x1a2b...c3d4",
    message: "GM YAP fam! Ready to make some noise today 🚀",
    timestamp: Date.now() - 1000 * 15, // 15 seconds ago
    upvotes: 12,
    upvotedBy: new Set(["0x5e6f...7g8h", "0x9i0j...k1l2"]),
    postCount: 1,
  },
  {
    id: "2",
    walletAddress: "0x5e6f...7g8h",
    message: "This glitch effect is sick! Love the vibe of this platform ⚡",
    timestamp: Date.now() - 1000 * 28, // 28 seconds ago
    upvotes: 8,
    upvotedBy: new Set(["0x1a2b...c3d4"]),
    postCount: 3,
  },
  {
    id: "3",
    walletAddress: "0x9i0j...k1l2",
    message: "YAP to the moon! 🌙 Who else is holding strong?",
    timestamp: Date.now() - 1000 * 42, // 42 seconds ago
    upvotes: 15,
    upvotedBy: new Set(["0x1a2b...c3d4", "0x5e6f...7g8h", "0xm3n4...o5p6"]),
    postCount: 2,
  },
  {
    id: "4",
    walletAddress: "0xm3n4...o5p6",
    message: "The future is decentralized. The future is YAP. 🔮",
    timestamp: Date.now() - 1000 * 55, // 55 seconds ago
    upvotes: 6,
    upvotedBy: new Set(["0x9i0j...k1l2"]),
    postCount: 5,
  },
  {
    id: "5",
    walletAddress: "0xq7r8...s9t0",
    message: "Just discovered YAP and I am OBSESSED with this concept! 💜",
    timestamp: Date.now() - 1000 * 8, // 8 seconds ago
    upvotes: 9,
    upvotedBy: new Set(["0x1a2b...c3d4", "0x5e6f...7g8h"]),
    postCount: 1,
  },
]

function HomeContent() {
  const [posts, setPosts] = useState(initialPosts)
  const [currentWallet] = useState(() => generateRandomWallet()) // Generate random wallet on each visit
  const [lastPostTime, setLastPostTime] = useState<Record<string, number>>({})

  // Add new post
  const addPost = (message: string) => {
    const now = Date.now()
    const newPost = {
      id: Date.now().toString(),
      walletAddress: currentWallet,
      message,
      timestamp: now,
      upvotes: 0,
      upvotedBy: new Set<string>(),
      postCount: posts.filter((p) => p.walletAddress === currentWallet).length + 1,
    }

    setPosts((prev) => [newPost, ...prev])
    setLastPostTime((prev) => ({ ...prev, [currentWallet]: now }))
  }

  // Toggle upvote
  const toggleUpvote = (postId: string) => {
    setPosts((prev) =>
      prev.map((post) => {
        if (post.id === postId) {
          const newUpvotedBy = new Set(post.upvotedBy)
          if (newUpvotedBy.has(currentWallet)) {
            newUpvotedBy.delete(currentWallet)
            return { ...post, upvotes: post.upvotes - 1, upvotedBy: newUpvotedBy }
          } else {
            newUpvotedBy.add(currentWallet)
            return { ...post, upvotes: post.upvotes + 1, upvotedBy: newUpvotedBy }
          }
        }
        return post
      }),
    )
  }

  // Check if wallet can post (once per 24h)
  const canPost = () => {
    const lastPost = lastPostTime[currentWallet]
    if (!lastPost) {
      // New wallet - 70% chance they can post immediately
      return Math.random() > 0.3
    }
    return Date.now() - lastPost >= 24 * 60 * 60 * 1000
  }

  // Remove posts older than 24h
  useEffect(() => {
    const interval = setInterval(() => {
      const now = Date.now()
      setPosts((prev) => prev.filter((post) => now - post.timestamp < 24 * 60 * 60 * 1000))
    }, 60000) // Check every minute

    return () => clearInterval(interval)
  }, [])

  // Add new posts periodically to simulate live activity
  useEffect(() => {
    const messages = [
      "LFG! YAP community is growing fast 🔥",
      "This is the future of social media 🚀",
      "Decentralized YAPs hit different 💎",
      "Who else is addicted to this platform? 😅",
      "The glitch effects are so cool! ⚡",
      "YAP to the moon! 🌙",
      "GM everyone! Ready to YAP today? ☀️",
      "This 24h limit makes every post count 💯",
      "Love the cyberpunk vibes here 🤖",
      "One YAP per day keeps the spam away 🛡️",
    ]

    const wallets = [
      "0xa1b2...c3d4",
      "0xe5f6...g7h8",
      "0xi9j0...k1l2",
      "0xm3n4...o5p6",
      "0xq7r8...s9t0",
      "0xu1v2...w3x4",
      "0xy5z6...a7b8",
      "0xc9d0...e1f2",
      "0xg3h4...i5j6",
    ]

    const interval = setInterval(
      () => {
        // 30% chance to add a new post every 10-20 seconds
        if (Math.random() < 0.3) {
          const randomMessage = messages[Math.floor(Math.random() * messages.length)]
          const randomWallet = wallets[Math.floor(Math.random() * wallets.length)]

          const newPost = {
            id: Date.now().toString() + Math.random(),
            walletAddress: randomWallet,
            message: randomMessage,
            timestamp: Date.now(),
            upvotes: Math.floor(Math.random() * 8), // Random upvotes 0-7
            upvotedBy: new Set<string>(),
            postCount: Math.floor(Math.random() * 4) + 1, // Random post count 1-4
          }

          setPosts((prev) => [newPost, ...prev.slice(0, 19)]) // Keep only latest 20 posts
        }
      },
      Math.random() * 10000 + 10000,
    ) // Random interval between 10-20 seconds

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="min-h-screen bg-background text-foreground font-mono transition-colors duration-300">
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        <Header />

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 mt-8">
          {/* Main Content */}
          <div className="lg:col-span-3 space-y-8">
            <PostForm
              onSubmit={addPost}
              canPost={canPost()}
              currentWallet={currentWallet}
              nextPostTime={lastPostTime[currentWallet] + 24 * 60 * 60 * 1000}
            />
            <YapWall posts={posts} currentWallet={currentWallet} onUpvote={toggleUpvote} />
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <Leaderboard posts={posts} />
          </div>
        </div>
      </div>
    </div>
  )
}

export default function Home() {
  return (
    <ThemeProvider>
      <HomeContent />
    </ThemeProvider>
  )
}
