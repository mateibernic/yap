import type React from "react"
import type { Metadata } from "next"
import { Libre_Baskerville } from "next/font/google"
import "./globals.css"

const libreBaskerville = Libre_Baskerville({
  subsets: ["latin"],
  weight: ["400", "700"],
  variable: "--font-libre-baskerville",
})

export const metadata: Metadata = {
  title: "$yap - Decentralized Noise Protocol",
  description: "One message per wallet per day. Make it count.",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className={libreBaskerville.variable}>
      <body>{children}</body>
    </html>
  )
}
